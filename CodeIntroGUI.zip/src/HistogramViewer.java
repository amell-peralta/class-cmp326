import javax.swing.JFrame;

public class HistogramViewer {
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	
	public static void main(String[] args) {
		JFrame window = new JFrame("Histogram");
		window.setSize(WIDTH, HEIGHT);
		window.add(new Histogram());
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}
}
