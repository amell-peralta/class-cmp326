import javax.swing.JFrame;

public class RandomShapes {
	public static void main(String[] args) {
		JFrame window = new JFrame("Random Colors");
		window.add(new RandomDrawing());
		window.setSize(640, 480);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
	}
}
