
public class Sample2Main {
	public static void main(String[] args) {
		Sample2 application = new Sample2();
	}
}
