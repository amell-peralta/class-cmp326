import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;

public class Histogram extends JComponent {
	@Override 
	public void paintComponent(Graphics g) {
		Graphics2D g2D = (Graphics2D) g;
		
		Rectangle rect1 = new Rectangle(10, 10, 200, 50);
		Color red = new Color(255, 0, 0);
		g2D.setColor(red);
		g2D.fill(rect1);
		
		Rectangle rect2 = new Rectangle(10, 75, 320, 50);
		Color green = new Color(0, 255, 0);
		g2D.setColor(green);
		g2D.fill(rect2);
		
		Rectangle rect3 = new Rectangle(10, 150, 160, 50);
		Color blue = new Color(0, 0, 255);
		g2D.setColor(blue);
		g2D.fill(rect3);
	}
}
