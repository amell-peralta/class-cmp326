import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setTitle("My First GUI");
		window.setSize(WIDTH, HEIGHT);
		
		JButton button1 = new JButton("Click me!");
		button1.addActionListener((e) -> {
			JOptionPane.showMessageDialog(window, "Hello world!");
		});
		
		JButton button2 = new JButton("Hi!");
		button2.addActionListener((e) -> {
			String name = JOptionPane.showInputDialog("Enter your name: ");
			JOptionPane.showMessageDialog(window, "Hello " + name + "!");
		});
		
		window.add(button1, BorderLayout.NORTH);
		window.add(button2, BorderLayout.SOUTH);
		
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLocationRelativeTo(null);
		window.setResizable(false);
		window.setVisible(true);
	}
}
