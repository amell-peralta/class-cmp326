import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.Random;

import javax.swing.JComponent;

public class RandomDrawing extends JComponent {
	private static final int NUM_SHAPES = 1000;
	private static final int WIDTH = 640;
	private static final int HEIGHT = 480;
	private final Random myRandom;
	
	public RandomDrawing() {
		myRandom = new Random();
	}
	
	@Override 
	public void paintComponent(Graphics g) {
		Graphics2D g2D = (Graphics2D) g;
		
		for (int i = 0; i < NUM_SHAPES; ++i) {
			int randomX = myRandom.nextInt(WIDTH);
			int randomY = myRandom.nextInt(HEIGHT);
			int randomWidth = myRandom.nextInt(200);
			int randomHeight = myRandom.nextInt(200);
			Ellipse2D.Double e = new Ellipse2D.Double(randomX, randomY, randomWidth, randomHeight);
			Color color = new Color(myRandom.nextInt(255), myRandom.nextInt(255), myRandom.nextInt(255));
			g2D.setColor(color);
			g2D.fill(e);
		}
	}
}
