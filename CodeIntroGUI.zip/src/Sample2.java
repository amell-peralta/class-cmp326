import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Sample2 extends JFrame {
	public Sample2() {
		super("Sample 2");
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JLabel label1 = new JLabel("Salary: ");
		JTextField textField1 = new JTextField(10);
		JButton button1 = new JButton("Display Salary");
		
		button1.addActionListener((e) -> {
			String text = textField1.getText();
			JOptionPane.showMessageDialog(null, text);
		});
		
		add(label1);
		add(textField1);
		add(button1);
		
		setLocationRelativeTo(null);
		pack();
		setVisible(true);
	}
}
